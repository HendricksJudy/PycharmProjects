# 伪随机模块 random

import random

# random.random() 返回 0-1 之间的随机小数 (左闭右开）
rdnum = random.random()
print(rdnum)

# random。randomrange(start, end, step value)   随机获取指定范围内的整数 end 必填
rardnum = random.randrange()

# random.randint()     产生指定范围内的随机整数

# random.uniform() 获取指定范围内的随机小数

# random.choice(container variation) 随机获取序列中的值

# random.shuffle() 随机打乱列表中的值， 没有返回值，直接打乱元数据


